﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Hány alkalommal legyen feldobás? ");
        int N = int.Parse(Console.ReadLine());

        Random random = new Random();
        int anniWins = 0;
        int panniWins = 0;

        for (int i = 0; i < N; i++)
        {

            int kocka1 = random.Next(1, 7);
            int kocka2 = random.Next(1, 7);
            int kocka3 = random.Next(1, 7);

            int osszeg = kocka1 + kocka2 + kocka3;
            string nyertes = (osszeg < 10) ? "Anni" : "Panni";

         
            Console.WriteLine($"Dobás: {kocka1} + {kocka2} + {kocka3} = {osszeg}  Nyert: {nyertes}");

          
            if (nyertes == "Anni")
            {
                anniWins++;
            }
            else
            {
                panniWins++;
            }
        }
        
        
 
        Console.WriteLine($"\nA játék során {anniWins} alkalommal Anni, {panniWins} alkalommal Panni nyert.");
        Console.ReadKey();
    }
}


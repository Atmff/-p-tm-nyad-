﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Adja meg a tömb méretét: ");
        int m = Convert.ToInt32(Console.ReadLine());

        int[] tombolom = new int[m];

        for (int i = 0; i < m; i++)
        {
            Console.Write($"Adja meg az {i + 1}. számot: ");
            tombolom[i] = Convert.ToInt32(Console.ReadLine());
        }

        if (m < 2)
        {
            Console.WriteLine("Legalább két számra van szükség a különbség számolásához.");
        }
        else
        {
            int legkisebb = tombolom[0];
            int legnagyobb = tombolom[0];

            for (int i = 1; i < m; i++)
            {
                if (tombolom[i] < legkisebb)
                {
                    legkisebb = tombolom[i];
                }
                if (tombolom[i] > legnagyobb)
                {
                    legnagyobb = tombolom[i];
                }
            }

            int kulonbseg = legnagyobb - legkisebb;
            Console.WriteLine($"A legnagyobb és legkisebb szám különbsége: {kulonbseg}");
            Console.ReadLine();
        }
    }
}



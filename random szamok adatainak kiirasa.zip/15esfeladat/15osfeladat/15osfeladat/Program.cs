﻿using System;

class Program
{
    static void Main()
    {
        int[] szamok = new int[28];  
        Random rand = new Random();

        int pozitiv = 0;
        int negativ = 0;
        int het = 0;
        int nulla = -1;
        int maxkicsi = int.MinValue;
        int sumnegat = 0;

        for (int i = 0; i < 28; i++)
        {
            szamok[i] = rand.Next(-10, 11);
            if (szamok[i] > 0)
            {
                pozitiv++;
            }
            else if (szamok[i] < 0)
            {
                negativ++;
                sumnegat += szamok[i];
                if (szamok[i] > maxkicsi)
                {
                    maxkicsi = szamok[i];
                }
            }
            if (szamok[i] == 7)
            {
                het++;
            }
            if (szamok[i] == 0 && nulla == -1)
            {
                nulla = i + 1;
            }
        }

        double averageNegative = negativ > 0 ? (double)sumnegat / negativ : 0;

        Console.WriteLine("Generált számok: ");
        foreach (var number in szamok)
        {
            Console.Write(number + " ");
        }
        Console.WriteLine();

        Console.WriteLine("Pozitív számok száma: " + pozitiv);
        Console.WriteLine("Negatív számok száma: " + negativ);
        Console.WriteLine("Negatív számok átlaga: " + averageNegative.ToString("0.00"));
        Console.WriteLine("Legnagyobb negatív szám: " + (negativ > 0 ? maxkicsi.ToString() : "Nincs negatív szám."));

        if (nulla != -1)
        {
            Console.WriteLine("Az első 0 szám indexe: " + nulla);
        }
        else
        {
            Console.WriteLine("Nem volt 0 szám a generált számok között.");
        }

        Console.WriteLine("Hányszor fordult elő a 7-es szám: " + het);

        if (pozitiv > negativ)
        {
            Console.WriteLine("Több pozitív szám van.");
        }
        else if (negativ > pozitiv)
        {
            Console.WriteLine("Több negatív szám van.");
        }
        else
        {
            Console.WriteLine("Ugyanannyi pozitív és negatív szám van.");
        }

        Console.ReadLine();
    }
}



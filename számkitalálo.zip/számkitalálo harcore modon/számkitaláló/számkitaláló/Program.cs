﻿using System;
using System.Collections.Generic;
using System.Text;
class Program
{
    static void Main(string[] args)
    {
        while (true)
        {
            Random rnd = new Random();
            int randno = rnd.Next(1, 101);
            int count = 1;
            while (true)
            {
                Console.Write("tippeltem egy szamra 1 és 100 kozott tippelj  ");
                int input = Convert.ToInt32(Console.ReadLine());

                 if (input < randno)
                {
                    Console.WriteLine("Kevés probáld ujra");
                    ++count;

                }
                else if (input > randno)
                {
                    Console.WriteLine("Magas probald ujra");
                    ++count;

                }
                else
                {
                    Console.WriteLine("Ezaz kitalaltad a szam {0}!",
                                       randno);
                    Console.WriteLine("ennyi probalkozasbol sikerult {0} {1}.\n", count,
                                       count == 1 ? "proba" : "probalkozas");
                    break;
                }
            }
        }

    }

}


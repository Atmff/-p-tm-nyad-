﻿using System;

class Program
{
    static void Main()
    {
        int[] suly = { 30, 155, 192, 133, 221, 22, 311, 34, 17, 544, 511, 515, 990, 1100 };
        int[] hossz = { 150, 200, 500, 300, 600, 300, 200, 142, 196, 100, 964, 376, 102, 111 };

        Random rand = new Random();
        int[]    = new int[28];


        double average = 0;
        int sum = 0;


        foreach (int sulyok in suly)
        {
            if (sulyok > 70)
            {
                Console.WriteLine(" hal sulyok amik nagyobbak 70 dkg nál "+sulyok);
            }
        }

        for (int i = 0; i < suly.Length; i++)
        {
            sum += suly[i];
        }

        average = (double)sum / suly.Length;

        Console.WriteLine(" A halak átlag súlya = " + average.ToString("N2"));

        Console.WriteLine(" Halak, amelyek súlya 50 dkg-nál több és hossza 28 cm-nél több: ");

        for (int i = 0; i < suly.Length; i++)
        {
            if (suly[i] > 50 && hossz[i] > 28)
            {
                Console.WriteLine("Súly: " + suly[i] + " dkg, Hossz: " + hossz[i] + " cm");
            }
        }
        foreach (int sus in suly)
        {
            if (sus > 200)
            {
                Console.WriteLine(" halak több mint 2kg nál " + sus);
            }
        }
       
        foreach (int suss in suly)
        {
            if (suss < 200)
            {
                Console.WriteLine(" halak kevesebb mint 20dkg nál " + suss);
            }
        }

        int legkisebbSuly = suly[0]; 
        int legkevesebb = hossz[0];
        foreach (int sulyy in suly)
        {
            if (sulyy < legkisebbSuly)
            {
                legkisebbSuly = sulyy; 
            }
        }

        Console.WriteLine("A legkisebb súlyú hal: " + legkisebbSuly);

        int legnagySuly = suly[0];
        foreach (int sulyyy in suly)
        {
            if (sulyyy > legnagySuly)
            {
                legnagySuly = sulyyy;
            }
        }

        Console.WriteLine("A legnagyobb súlyú hal: " + legnagySuly);




        Console.ReadLine();
    }
}


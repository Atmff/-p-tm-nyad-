﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace masodfokuegyenletmegoldasa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program masodfoku egyenletet szamol ki");
            Console.WriteLine("az egyenlet alakja ax^2 + bx + c = 0");
            Console.WriteLine("Kerem a főegyüttható az (a) értékét");
            double a =Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Kerem a másodikegyüttható a (b) értékét");
            double  b = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Kerem a harmadikegyüttható a(c) értékét");
            double c = Convert.ToDouble(Console.ReadLine());

            double eredmeny1 = Math.Sqrt(b * b - 4 * a * c);
            double eredmeny3 = (-b + eredmeny1);
            double eredmeny4 = (-b - eredmeny1);
            double osztas = (2 * a);
            double eredmeny5 = (eredmeny3 / osztas);
            double eredmeny6 = (eredmeny4 / osztas);
            Console.WriteLine("Az első megoldás: {0:0.00}",eredmeny5);
            Console.WriteLine("A második megoldás: {0:0.00}", eredmeny6);


            Console.ReadKey();

        }
    }
}

﻿using System;

namespace NegyAlapMuveletValamelyike
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ebben a programban kiszámíthatod a négy alap művelet valamelyikét, amit kiválaszthatsz.");
            Console.WriteLine("Kérem az első számot");
            double elsoszam = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Kérem a második számot");
            double masodikszam = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Összeadás, kivonás, osztás vagy szorzás legyen?");
            string muvelet = Console.ReadLine();

            switch (muvelet)
            {
                case "összeadás":
                    Console.WriteLine(elsoszam + masodikszam);
                    break;
                case "kivonás":
                    Console.WriteLine(elsoszam - masodikszam);
                    break;
                case "osztás":
                    if (masodikszam != 0)
                    {
                        Console.WriteLine(elsoszam / masodikszam);
                    }
                    else
                    {
                        Console.WriteLine("Hiba: Nullával nem lehet osztani.");
                    }
                    break;
                case "szorzás":
                    Console.WriteLine(elsoszam * masodikszam);
                    break;
                default:
                    Console.WriteLine("Érvénytelen művelet.");
                    break;

            }
            Console.ReadLine();
        }
    }
}


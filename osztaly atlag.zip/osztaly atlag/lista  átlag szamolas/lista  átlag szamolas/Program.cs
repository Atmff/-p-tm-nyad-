﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lista__átlag_szamolas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] jegyek = { 2, 5, 3, 1, 2, 5, 3, 4, 1, 2 };
            string[] nevek = { "Kathi", "Béla", "Ádám", "asztal", "ferko" };

            double osztalyAtlag = SzamolOsztalyAtlag(jegyek);
            Console.WriteLine("Osztály átlaga: " + osztalyAtlag);

            for (int i = 0; i < nevek.Length; i++)
            {
                if (jegyek[i] > osztalyAtlag)
                {
                    Console.WriteLine(nevek[i] + " pontszáma magasabb az osztályátlagnál.");
                }
            }

            Console.ReadLine();
        }

        static double SzamolOsztalyAtlag(int[] pontszamok)
        {
            int osszeg = 0;
            foreach (int pontszam in pontszamok)
            {
                osszeg += pontszam;
            }

            return (double)osszeg / pontszamok.Length;
        }
    }
}




﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ez a program bekér számokat, amikor 0-t írsz, akkor nem kér be több számot és kiírja a számokat sorrendben és hogy hanyadik az a szám.");
        List<int> szamok = new List<int>();
        int beirtSzam;
        int asd;
        int szamlalo = 1;

        while (true)
        {
            Console.Write($"Kérem adjon meg egy pozitív számot (0-kilépés): ");
            if (int.TryParse(Console.ReadLine(), out beirtSzam))
            {
                if (beirtSzam == 0)
                    break;
                else if (beirtSzam < 0)
                {
                    Console.WriteLine("Negatív számot nem fogadunk el. Kérem adjon meg egy pozitív számot.");
                }
                else
                {
                    szamok.Add(beirtSzam);
                    szamlalo++;
                }
            }
            else
            {
                Console.WriteLine("Érvénytelen szám! Kérem adjon meg egy érvényes pozitív számot.");
            }
        }

        Console.WriteLine("A megadott számok a következő sorrendben:");
        for (int i = 0; i < szamok.Count; i++)
        {
            Console.WriteLine($"{i + 1}. szám: {szamok[i]}");
        }

        while (true)
        {
            Console.WriteLine(" 99");
            if (int.TryParse(Console.ReadLine(), out asd))
            {
                if (asd == 99)
                    break;
                else if (asd < 99)
                {
                    Console.WriteLine("Akkor vagyunk végig.");
                }
            }
        }

        Console.ReadLine();
    }
}
